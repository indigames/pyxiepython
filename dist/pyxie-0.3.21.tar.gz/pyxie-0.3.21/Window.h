#pragma once


void CreateMyWindow();
void Sync();
void Finalize();
