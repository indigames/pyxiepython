pyvmath
--------

C++ extension Vector Mathematics Package for 3D and 2D games.
-------------------------------------------------------------

object
vec2	2D vector
vec3	3D vector
vec4	4D vector
quat	Quaternion
mat22	2x2 matrix
mat33	3x3 matrix
mat44	4x4 matrix

