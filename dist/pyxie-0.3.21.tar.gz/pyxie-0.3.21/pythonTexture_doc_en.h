//showcase
PyDoc_STRVAR(texture_doc,
	"Textures are RGBA bitmap image objects \n"\
	"\n"\
	"tex = pyxie.texture()");

//setImage
PyDoc_STRVAR(setImage_doc,
	"Add object to showcase\n"\
	"\n"\
	"texture.setImage(rawdata, alpha)\n"\
	"\n"\
	"Parameters\n"\
	"----------\n"\
	"    rawdata : binary\n"\
	"        rgb or rgba raw image data");
